﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FInicio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblhora = New System.Windows.Forms.Label()
        Me.lbldia = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblequipo = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnventas = New System.Windows.Forms.Button()
        Me.btnproductos = New System.Windows.Forms.Button()
        Me.btnempleados = New System.Windows.Forms.Button()
        Me.btnclientes = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(171, 56)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(668, 399)
        Me.Panel1.TabIndex = 0
        '
        'lblhora
        '
        Me.lblhora.AutoSize = True
        Me.lblhora.BackColor = System.Drawing.SystemColors.Control
        Me.lblhora.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhora.Location = New System.Drawing.Point(703, 9)
        Me.lblhora.Name = "lblhora"
        Me.lblhora.Size = New System.Drawing.Size(40, 20)
        Me.lblhora.TabIndex = 7
        Me.lblhora.Text = "0:00"
        '
        'lbldia
        '
        Me.lbldia.AutoSize = True
        Me.lbldia.BackColor = System.Drawing.SystemColors.Control
        Me.lbldia.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldia.Location = New System.Drawing.Point(12, 9)
        Me.lbldia.Name = "lbldia"
        Me.lbldia.Size = New System.Drawing.Size(18, 20)
        Me.lbldia.TabIndex = 7
        Me.lbldia.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(16, 429)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Equipo:"
        '
        'lblequipo
        '
        Me.lblequipo.AutoSize = True
        Me.lblequipo.BackColor = System.Drawing.SystemColors.Control
        Me.lblequipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblequipo.Location = New System.Drawing.Point(65, 429)
        Me.lblequipo.Name = "lblequipo"
        Me.lblequipo.Size = New System.Drawing.Size(14, 13)
        Me.lblequipo.TabIndex = 7
        Me.lblequipo.Text = "0"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(6, 331)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(88, 32)
        Me.btnSalir.TabIndex = 8
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'btnventas
        '
        Me.btnventas.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnventas.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnventas.Location = New System.Drawing.Point(6, 259)
        Me.btnventas.Name = "btnventas"
        Me.btnventas.Size = New System.Drawing.Size(153, 50)
        Me.btnventas.TabIndex = 6
        Me.btnventas.Text = "Ventas"
        Me.btnventas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnventas.UseVisualStyleBackColor = False
        '
        'btnproductos
        '
        Me.btnproductos.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnproductos.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnproductos.Location = New System.Drawing.Point(6, 203)
        Me.btnproductos.Name = "btnproductos"
        Me.btnproductos.Size = New System.Drawing.Size(153, 50)
        Me.btnproductos.TabIndex = 3
        Me.btnproductos.Text = "Productos"
        Me.btnproductos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnproductos.UseVisualStyleBackColor = False
        '
        'btnempleados
        '
        Me.btnempleados.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnempleados.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnempleados.Location = New System.Drawing.Point(6, 146)
        Me.btnempleados.Name = "btnempleados"
        Me.btnempleados.Size = New System.Drawing.Size(153, 50)
        Me.btnempleados.TabIndex = 2
        Me.btnempleados.Text = "Empleados"
        Me.btnempleados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnempleados.UseVisualStyleBackColor = False
        '
        'btnclientes
        '
        Me.btnclientes.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnclientes.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclientes.Location = New System.Drawing.Point(6, 89)
        Me.btnclientes.Name = "btnclientes"
        Me.btnclientes.Size = New System.Drawing.Size(153, 50)
        Me.btnclientes.TabIndex = 1
        Me.btnclientes.Text = "Clientes"
        Me.btnclientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnclientes.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(839, 53)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Punto de Venta Comercializadora"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FInicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(839, 451)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.lblequipo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lbldia)
        Me.Controls.Add(Me.lblhora)
        Me.Controls.Add(Me.btnventas)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnproductos)
        Me.Controls.Add(Me.btnempleados)
        Me.Controls.Add(Me.btnclientes)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximumSize = New System.Drawing.Size(855, 490)
        Me.MinimumSize = New System.Drawing.Size(855, 490)
        Me.Name = "FInicio"
        Me.Text = "Página principal"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnclientes As System.Windows.Forms.Button
    Friend WithEvents btnempleados As System.Windows.Forms.Button
    Friend WithEvents btnproductos As System.Windows.Forms.Button
    Friend WithEvents btnventas As System.Windows.Forms.Button
    Friend WithEvents lblhora As System.Windows.Forms.Label
    Friend WithEvents lbldia As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblequipo As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
