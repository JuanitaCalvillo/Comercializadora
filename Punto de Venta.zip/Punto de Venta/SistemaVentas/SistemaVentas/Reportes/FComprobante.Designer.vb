﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FComprobante
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.GenerarComprobanteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Punto_de_Venta_ComercializadoraDataSet = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSet()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.GenerarComprobanteTableAdapter = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.GenerarComprobanteTableAdapter()
        Me.datosventasDataSet1 = New SistemaVentas.datosventasDataSet1()
        CType(Me.GenerarComprobanteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Punto_de_Venta_ComercializadoraDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datosventasDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GenerarComprobanteBindingSource
        '
        Me.GenerarComprobanteBindingSource.DataMember = "GenerarComprobante"
        Me.GenerarComprobanteBindingSource.DataSource = Me.Punto_de_Venta_ComercializadoraDataSet
        '
        'Punto_de_Venta_ComercializadoraDataSet
        '
        Me.Punto_de_Venta_ComercializadoraDataSet.DataSetName = "datosventasDataSet"
        Me.Punto_de_Venta_ComercializadoraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.GenerarComprobanteBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "SistemaVentas.RReporteVenta.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(635, 486)
        Me.ReportViewer1.TabIndex = 0
        '
        'GenerarComprobanteTableAdapter
        '
        Me.GenerarComprobanteTableAdapter.ClearBeforeFill = True
        '
        'datosventasDataSet1
        '
        Me.datosventasDataSet1.DataSetName = "datosventasDataSet1"
        Me.datosventasDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FComprobante
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(635, 486)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "FComprobante"
        Me.Text = "FComprobante"
        CType(Me.GenerarComprobanteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Punto_de_Venta_ComercializadoraDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datosventasDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents GenerarComprobanteBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Punto_de_Venta_ComercializadoraDataSet As SistemaVentas.Punto_de_Venta_ComercializadoraDataSet
    Friend WithEvents GenerarComprobanteTableAdapter As SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.GenerarComprobanteTableAdapter
    Friend WithEvents datosventasDataSet1 As SistemaVentas.datosventasDataSet1
End Class
