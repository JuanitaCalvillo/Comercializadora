﻿Public Class ReporteVenta

    Private Sub RepVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'Punto_de_Venta_ComercializadoraDataSet.Venta' Puede moverla o quitarla según sea necesario.
        Me.VentaTableAdapter.Fill(Me.Punto_de_Venta_ComercializadoraDataSet.Venta)
        'TODO: esta línea de código carga datos en la tabla 'Punto_de_Venta_ComercializadoraDataSet.Empleado' Puede moverla o quitarla según sea necesario.
        Me.EmpleadoTableAdapter.Fill(Me.Punto_de_Venta_ComercializadoraDataSet.Empleado)
        'TODO: esta línea de código carga datos en la tabla 'Punto_de_Venta_ComercializadoraDataSet.MostrarVenta' Puede moverla o quitarla según sea necesario.
        Me.MostrarVentaTableAdapter.Fill(Me.Punto_de_Venta_ComercializadoraDataSet.MostrarVenta)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class