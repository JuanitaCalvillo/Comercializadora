﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReporteVenta
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.Punto_de_Venta_ComercializadoraDataSet = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSet()
        Me.MostrarVentaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MostrarVentaTableAdapter = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.MostrarVentaTableAdapter()
        Me.EmpleadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmpleadoTableAdapter = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.EmpleadoTableAdapter()
        Me.VentaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VentaTableAdapter = New SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.VentaTableAdapter()
        CType(Me.Punto_de_Venta_ComercializadoraDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MostrarVentaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmpleadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VentaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.VentaBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "SistemaVentas.Report2.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 2)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(872, 398)
        Me.ReportViewer1.TabIndex = 0
        '
        'Punto_de_Venta_ComercializadoraDataSet
        '
        Me.Punto_de_Venta_ComercializadoraDataSet.DataSetName = "Punto_de_Venta_ComercializadoraDataSet"
        Me.Punto_de_Venta_ComercializadoraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MostrarVentaBindingSource
        '
        Me.MostrarVentaBindingSource.DataMember = "MostrarVenta"
        Me.MostrarVentaBindingSource.DataSource = Me.Punto_de_Venta_ComercializadoraDataSet
        '
        'MostrarVentaTableAdapter
        '
        Me.MostrarVentaTableAdapter.ClearBeforeFill = True
        '
        'EmpleadoBindingSource
        '
        Me.EmpleadoBindingSource.DataMember = "Empleado"
        Me.EmpleadoBindingSource.DataSource = Me.Punto_de_Venta_ComercializadoraDataSet
        '
        'EmpleadoTableAdapter
        '
        Me.EmpleadoTableAdapter.ClearBeforeFill = True
        '
        'VentaBindingSource
        '
        Me.VentaBindingSource.DataMember = "Venta"
        Me.VentaBindingSource.DataSource = Me.Punto_de_Venta_ComercializadoraDataSet
        '
        'VentaTableAdapter
        '
        Me.VentaTableAdapter.ClearBeforeFill = True
        '
        'RepVentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(869, 404)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "RepVentas"
        Me.Text = "RepVentas"
        CType(Me.Punto_de_Venta_ComercializadoraDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MostrarVentaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmpleadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VentaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents MostrarVentaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Punto_de_Venta_ComercializadoraDataSet As SistemaVentas.Punto_de_Venta_ComercializadoraDataSet
    Friend WithEvents MostrarVentaTableAdapter As SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.MostrarVentaTableAdapter
    Friend WithEvents EmpleadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmpleadoTableAdapter As SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.EmpleadoTableAdapter
    Friend WithEvents VentaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VentaTableAdapter As SistemaVentas.Punto_de_Venta_ComercializadoraDataSetTableAdapters.VentaTableAdapter
End Class
