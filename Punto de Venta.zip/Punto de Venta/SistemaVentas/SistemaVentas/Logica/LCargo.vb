﻿Public Class LCargo
    Dim descripcion As String

    Public Property _descripcion
        Set(value)
            descripcion = value
        End Set
        Get
            Return descripcion
        End Get
    End Property
End Class
